-- Run on the PRIMARY as a PostgreSQL administrator.
-- Replace the placeholder with a strong unique secret; do not commit real secrets.
CREATE ROLE replicator
WITH LOGIN REPLICATION
PASSWORD 'REPLACE_WITH_A_LONG_UNIQUE_PASSWORD';
